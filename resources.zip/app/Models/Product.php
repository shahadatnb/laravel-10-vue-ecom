<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $hidden = [
        'short_description',
        'description',
    ];
    
    protected $fillable = [ 'title','sku', 'price','weight','reduced_price','brand_id','featured','description','status','user_id','photo','variant_id']; 	 	
    // public function cat(){
    // 	return $this->hasOne('App\ProCat','id','cat_id');
    // }
    public function categories(){
    	return $this->belongsToMany(ProCat::class,'product_category','product_id','category_id');
    }
    
    public function colors(){
        return $this->belongsToMany(Color::class,'product_colors','product_id','color_id');
    }

    public function sizes(){
        return $this->belongsToMany(Size::class,'product_sizes','product_id','size_id');
    }

    public function variants(){
        return $this->hasMany(ProductStock::class,'product_id','id');
    }

    public function price(){
        $old_price = $this->price;
        $reduced_price = $this->reduced_price;
        if($reduced_price > 0){
            $price = $reduced_price;
        }else{
            $price = $old_price;
        }
        return $price;
    }

    public function galleries(){
        return $this->hasMany(Attachment::class,'product_id','id')->whereNull('color_id');
    }
    
}
