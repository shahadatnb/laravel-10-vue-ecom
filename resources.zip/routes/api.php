<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrontendController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\WishlistController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ColorController;
use App\Http\Controllers\SizeController;
use App\Http\Controllers\LocationController;
use App\Http\Controllers\ShippingRoleController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::apiResource('users', UserController::class)->except(['edit', 'create', 'store', 'update'])->middleware(['auth:sanctum', 'ability:admin,super-admin']);
Route::post('users', [UserController::class, 'store']);
Route::put('users/{user}', [UserController::class, 'update'])->middleware(['auth:sanctum', 'ability:admin,super-admin,user']);
Route::post('users/{user}', [UserController::class, 'update'])->middleware(['auth:sanctum', 'ability:admin,super-admin,user']);
Route::patch('users/{user}', [UserController::class, 'update'])->middleware(['auth:sanctum', 'ability:admin,super-admin,user']);
Route::get('getProfile', [CustomerController::class, 'getProfile'])->middleware('auth:sanctum');
Route::post('updateProfile', [CustomerController::class, 'updateProfileApi'])->middleware('auth:sanctum');
Route::post('register', [CustomerController::class, 'registerApi']);
Route::post('login', [CustomerController::class, 'login']);

Route::get( '/posts', [FrontendController::class, 'getPosts'] );
Route::get( '/page/{slug}', [FrontendController::class, 'getPage'] );
Route::get( '/menu', [FrontendController::class, 'menuApi'] );
Route::get( '/config', [FrontendController::class, 'getConfig'] );

Route::post('/placeOrderNonAuth', [CheckoutController::class, 'placeOrderNonAuth']);//->middleware('cors');
Route::post('/checkout', [CheckoutController::class, 'checkout'])->middleware('auth:sanctum');

Route::get(
    '/orders',
    [OrderController::class, 'getUserOrders']
)->middleware('auth:sanctum');

Route::get(
    '/order/{id}',
    [OrderController::class, 'getOrderDetails']
)->middleware('auth:sanctum');

// Wishlist
Route::post(
    '/wishlist',
    [WishlistController::class, 'addToWishList']
)->middleware('auth:sanctum');

Route::get(
    '/wishlist',
    [WishlistController::class, 'getWishList']
)->middleware('auth:sanctum');

Route::delete(
    '/wishlist/{product_id}',
    [WishlistController::class, 'removeFromWishList']
)->middleware('auth:sanctum');
//end

Route::get('/wish-listed-products', [FrontendController::class, 'getWishlistedProduct'])->middleware('auth:sanctum');
Route::get('/latest-products', [FrontendController::class, 'latestProducts']);//->middleware('cors');
Route::get('/search-products', [FrontendController::class, 'searchProducts']);//->middleware('cors');
Route::get('/single-product/{slug}', [FrontendController::class, 'getProduct']);//->middleware('cors');
Route::get('/product-variant-gallery/{product_id}/{color_id}', [FrontendController::class, 'getProductVariantGallery']);//->middleware('cors');

Route::get('/categories', [FrontendController::class, 'getCategories']);//->middleware('cors');
Route::get('/sizes', [SizeController::class, 'getSizes']);//->middleware('cors');
Route::get('/colors', [ColorController::class, 'getColors']);//->middleware('cors');
Route::get('/getLocation', [LocationController::class, 'getLocation']);//->middleware('cors');
Route::get('/shippingAmount', [ShippingRoleController::class, 'shippingAmount']);//->middleware('cors');
